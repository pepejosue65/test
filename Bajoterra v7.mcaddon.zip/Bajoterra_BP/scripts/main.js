import { world } from "@minecraft/server";

world.afterEvents.entityHurt.subscribe((event) => {
  const damageSource = event.damageSource;
  const attacker = damageSource.damagingEntity;
  const victim = event.hurtEntity;

  if (attacker && attacker.typeId === "bajoterra:infernus_slug") {
    if (Math.random() < 0.25) {
      victim.setOnFire(5, true);
    }
  }
});