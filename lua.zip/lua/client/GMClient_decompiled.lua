local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1
L0_1 = require
L1_1 = "common.FeatureSwitchConfig"
L0_1 = L0_1(L1_1)
L1_1 = require
L2_1 = "common.MysteryWeaponConfig"
L1_1 = L1_1(L2_1)

function L2_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = L0_1
  L2_2 = L1_2
  L1_2 = L1_2.isEnabled
  L3_2 = A0_2
  return L1_2(L2_2, L3_2)
end

function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L0_2 = {}
  L1_2 = {}
  L2_2 = L1_1
  L3_2 = L2_2
  L2_2 = L2_2.getAll
  L2_2 = L2_2(L3_2)
  L3_2 = ipairs
  L4_2 = L2_2
  L3_2, L4_2, L5_2 = L3_2(L4_2)
  for L6_2, L7_2 in L3_2, L4_2, L5_2 do
    L8_2 = tonumber
    L9_2 = L7_2.itemId
    L8_2 = L8_2(L9_2)
    if L8_2 then
      L9_2 = L1_2[L8_2]
      if not L9_2 then
        L1_2[L8_2] = true
        L9_2 = table
        L9_2 = L9_2.insert
        L10_2 = L0_2
        L11_2 = L8_2
        L9_2(L10_2, L11_2)
      end
    end
  end
  L3_2 = ipairs
  L4_2 = L2_2
  L3_2, L4_2, L5_2 = L3_2(L4_2)
  for L6_2, L7_2 in L3_2, L4_2, L5_2 do
    L8_2 = tonumber
    L9_2 = L7_2.ammoItemId
    L8_2 = L8_2(L9_2)
    if L8_2 then
      L9_2 = L1_2[L8_2]
      if not L9_2 then
        L1_2[L8_2] = true
        L9_2 = table
        L9_2 = L9_2.insert
        L10_2 = L0_2
        L11_2 = L8_2
        L9_2(L10_2, L11_2)
      end
    end
  end
  L3_2 = L0_2
  L4_2 = L1_2
  return L3_2, L4_2
end

L4_1 = nil

function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L0_2 = L4_1
  if L0_2 then
    L0_2 = L4_1
    return L0_2
  end
  L0_2 = {}
  L4_1 = L0_2
  L0_2 = FileUtil
  if L0_2 then
    L0_2 = type
    L1_2 = FileUtil
    L1_2 = L1_2.getRootPath
    L0_2 = L0_2(L1_2)
    if L0_2 == "function" then
      L0_2 = type
      L1_2 = FileUtil
      L1_2 = L1_2.getSettingPath
      L0_2 = L0_2(L1_2)
      if L0_2 == "function" then
        goto lbl_25
      end
    end
  end
  L0_2 = L4_1
  do return L0_2 end
  ::lbl_25::
  L0_2 = FileUtil
  L1_2 = L0_2
  L0_2 = L0_2.getRootPath
  L0_2 = L0_2(L1_2)
  L1_2 = FileUtil
  L2_2 = L1_2
  L1_2 = L1_2.getSettingPath
  L1_2 = L1_2(L2_2)
  L2_2 = {}
  L3_2 = L0_2
  L4_2 = "Media/Lang/Text/zh.lang"
  L3_2 = L3_2 .. L4_2
  L4_2 = L0_2
  L5_2 = "Media/Lang/decoration/zh.decoration.lang"
  L4_2 = L4_2 .. L5_2
  L5_2 = L0_2
  L6_2 = "Media/Scripts/Engine/setting/lang/zh.lang"
  L5_2 = L5_2 .. L6_2
  L6_2 = L1_2
  L7_2 = "lang/zh.lang"
  L6_2 = L6_2 .. L7_2
  L2_2[1] = L3_2
  L2_2[2] = L4_2
  L2_2[3] = L5_2
  L2_2[4] = L6_2
  L3_2 = ipairs
  L4_2 = L2_2
  L3_2, L4_2, L5_2 = L3_2(L4_2)
  for L6_2, L7_2 in L3_2, L4_2, L5_2 do
    L8_2 = io
    L8_2 = L8_2.open
    L9_2 = L7_2
    L10_2 = "r"
    L8_2 = L8_2(L9_2, L10_2)
    if L8_2 then
      while true do
        L10_2 = L8_2
        L9_2 = L8_2.read
        L9_2 = L9_2(L10_2)
        if L9_2 == nil then
          break
        end
        L10_2 = string
        L10_2 = L10_2.find
        L11_2 = L9_2
        L12_2 = "="
        L13_2 = 1
        L14_2 = true
        L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2)
        L11_2 = string
        L11_2 = L11_2.sub
        L12_2 = L9_2
        L13_2 = 1
        L14_2 = 1
        L11_2 = L11_2(L12_2, L13_2, L14_2)
        if L10_2 and 1 < L10_2 and L11_2 ~= "#" and L11_2 ~= "@" then
          L12_2 = string
          L12_2 = L12_2.sub
          L13_2 = L9_2
          L14_2 = 1
          L15_2 = L10_2 - 1
          L12_2 = L12_2(L13_2, L14_2, L15_2)
          L13_2 = string
          L13_2 = L13_2.gsub
          L14_2 = L12_2
          L15_2 = "^\239\187\191"
          L16_2 = ""
          L13_2 = L13_2(L14_2, L15_2, L16_2)
          L12_2 = L13_2
          L13_2 = string
          L13_2 = L13_2.sub
          L14_2 = L9_2
          L15_2 = L10_2 + 1
          L13_2 = L13_2(L14_2, L15_2)
          L14_2 = string
          L14_2 = L14_2.gsub
          L15_2 = L13_2
          L16_2 = "\\\\n"
          L17_2 = "\n"
          L14_2 = L14_2(L15_2, L16_2, L17_2)
          L4_1[L12_2] = L14_2
        end
      end
      L10_2 = L8_2
      L9_2 = L8_2.close
      L9_2(L10_2)
    end
  end
  L3_2 = L4_1
  return L3_2
end

function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = tostring
  L3_2 = A0_2
  L2_2 = A0_2.getUnlocalizedName
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = ""
  end
  L1_2 = L1_2(L2_2)
  L2_2 = L5_1
  L2_2 = L2_2()
  L3_2 = L1_2
  L4_2 = ".name"
  L3_2 = L3_2 .. L4_2
  L2_2 = L2_2[L3_2]
  L3_2 = L2_2 or L3_2
  if not L2_2 or L2_2 == "" or not L2_2 then
    L3_2 = L1_2
  end
  return L3_2
end

function L7_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = Item
  L2_2 = L2_2.getItemById
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    return
  end
  L3_2 = L6_1
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = GMSetting
  L5_2 = L4_2
  L4_2 = L4_2.addItem
  L6_2 = A0_2
  L7_2 = tostring
  L8_2 = A1_2
  L7_2 = L7_2(L8_2)
  L8_2 = "-"
  L9_2 = L3_2
  L7_2 = L7_2 .. L8_2 .. L9_2
  L8_2 = "addItem"
  L9_2 = A1_2
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
end

function L8_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L0_2 = require
  L1_2 = "config.GMItemGameCatalog"
  L0_2 = L0_2(L1_2)
  L1_2 = L3_1
  L1_2, L2_2 = L1_2()
  L3_2 = ipairs
  L4_2 = L0_2
  L3_2, L4_2, L5_2 = L3_2(L4_2)
  for L6_2, L7_2 in L3_2, L4_2, L5_2 do
    L8_2 = "\229\138\160\233\129\147\229\133\183-"
    L9_2 = L7_2.gameType
    L8_2 = L8_2 .. L9_2
    L9_2 = GMSetting
    L10_2 = L9_2
    L9_2 = L9_2.addTab
    L11_2 = L8_2
    L9_2(L10_2, L11_2)
    L9_2 = GMSetting
    L10_2 = L9_2
    L9_2 = L9_2.addItem
    L11_2 = L8_2
    L12_2 = "+\230\140\135\229\174\154\233\129\147\229\133\183"
    L13_2 = "addInputItem"
    L9_2(L10_2, L11_2, L12_2, L13_2)
    L9_2 = L7_2.itemIds
    L9_2 = #L9_2
    L10_2 = 1
    L11_2 = -1
    for L12_2 = L9_2, L10_2, L11_2 do
      L13_2 = L7_2.itemIds
      L13_2 = L13_2[L12_2]
      L14_2 = tonumber
      L15_2 = L13_2
      L14_2 = L14_2(L15_2)
      L14_2 = L2_2[L14_2]
      if not L14_2 then
        L14_2 = L7_1
        L15_2 = L8_2
        L16_2 = L13_2
        L14_2(L15_2, L16_2)
      end
    end
  end
  L3_2 = L2_1
  L4_2 = L0_1.MYSTERY_WEAPON
  L3_2 = L3_2(L4_2)
  if L3_2 then
    L3_2 = "\229\138\160\233\129\147\229\133\183-\231\165\158\231\167\152\230\173\166\229\153\168"
    L4_2 = GMSetting
    L5_2 = L4_2
    L4_2 = L4_2.addTab
    L6_2 = L3_2
    L4_2(L5_2, L6_2)
    L4_2 = GMSetting
    L5_2 = L4_2
    L4_2 = L4_2.addItem
    L6_2 = L3_2
    L7_2 = "+\230\140\135\229\174\154\233\129\147\229\133\183"
    L8_2 = "addInputItem"
    L4_2(L5_2, L6_2, L7_2, L8_2)
    L4_2 = #L1_2
    L5_2 = 1
    L6_2 = -1
    for L7_2 = L4_2, L5_2, L6_2 do
      L8_2 = L7_1
      L9_2 = L3_2
      L10_2 = L1_2[L7_2]
      L8_2(L9_2, L10_2)
    end
  end
end

L9_1 = isTest
if not L9_1 then
  L9_1 = isStaging
  if not L9_1 then
    goto lbl_22
  end
end
L9_1 = L8_1
L9_1()
::lbl_22::
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addTab
L11_1 = "G1014"
L9_1(L10_1, L11_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\232\174\162\233\152\133\230\163\128\230\181\139"
L13_1 = "subVipCheck"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\233\135\141\231\189\174\230\155\180\230\150\176\229\133\172\229\145\138"
L13_1 = "resetUpdateNotice"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\231\165\158\231\167\152\229\188\185\232\141\175\232\181\160\233\128\129-\230\184\133\233\153\164\233\162\134\229\143\150\230\151\182\233\151\180"
L13_1 = "resetMysteryAmmoGift"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\229\135\187\230\157\128\230\146\173\230\138\165-\230\156\172\228\186\186\230\181\139\232\175\149"
L13_1 = "g1014TestSelfKillBroadcast"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\229\135\187\230\157\128\230\146\173\230\138\165-\233\154\143\230\156\186\230\181\139\232\175\149"
L13_1 = "g1014TestRandomKillBroadcast"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "NPC\231\130\185\228\189\141\233\133\141\231\189\174\229\153\168"
L13_1 = "g1014NpcPointConfigurator"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\229\141\160\233\162\134\229\140\186\233\133\141\231\189\174\229\153\168"
L13_1 = "g1014CaptureZoneConfigurator"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\229\174\157\231\174\177\233\133\141\231\189\174\229\153\168"
L13_1 = "g1014ChestConfigurator"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\232\161\151\229\140\186\233\133\141\231\189\174\229\153\168"
L13_1 = "g1014StreetDistrictConfigurator"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\229\176\143\229\156\176\229\155\190\229\155\190\230\160\135\230\145\134\230\148\190"
L13_1 = "g1014MiniMapZoneIconConfigurator"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\229\188\128\229\144\175/\229\133\179\233\151\173\229\156\176\229\155\190\229\190\174\232\176\131\230\168\161\229\188\143"
L13_1 = "g1014ToggleMapFineTune"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = GMSetting
L10_1 = L9_1
L9_1 = L9_1.addItem
L11_1 = "G1014"
L12_1 = "\228\191\157\229\173\152\229\190\174\232\176\131\229\156\176\229\155\190"
L13_1 = "g1014SaveMapFineTune"
L9_1(L10_1, L11_1, L12_1, L13_1)
L9_1 = L2_1
L10_1 = L0_1.NEWS
L9_1 = L9_1(L10_1)
if L9_1 then
  L9_1 = GMSetting
  L10_1 = L9_1
  L9_1 = L9_1.addItem
  L11_1 = "G1014"
  L12_1 = "\230\150\176\233\151\187-\233\135\141\231\189\174\230\175\143\230\151\165\228\187\187\229\138\161"
  L13_1 = "g1014NewsResetDaily"
  L9_1(L10_1, L11_1, L12_1, L13_1)
  L9_1 = GMSetting
  L10_1 = L9_1
  L9_1 = L9_1.addItem
  L11_1 = "G1014"
  L12_1 = "\230\150\176\233\151\187-\229\174\140\230\136\144\229\189\147\229\137\141\228\187\187\229\138\161"
  L13_1 = "g1014NewsCompleteAll"
  L9_1(L10_1, L11_1, L12_1, L13_1)
  L9_1 = GMSetting
  L10_1 = L9_1
  L9_1 = L9_1.addItem
  L11_1 = "G1014"
  L12_1 = "\230\150\176\233\151\187-\229\162\158\229\138\16010\229\184\130\230\176\145\231\130\185\230\149\176"
  L13_1 = "g1014NewsAddPoints"
  L9_1(L10_1, L11_1, L12_1, L13_1)
  L9_1 = GMSetting
  L10_1 = L9_1
  L9_1 = L9_1.addItem
  L11_1 = "G1014"
  L12_1 = "\230\150\176\233\151\187-\230\168\161\230\139\159\230\156\136\231\187\147"
  L13_1 = "g1014NewsSettleMonth"
  L9_1(L10_1, L11_1, L12_1, L13_1)
end
L9_1 = L2_1
L10_1 = L0_1.EMERGENCY_EVENT
L9_1 = L9_1(L10_1)
if L9_1 then
  L9_1 = GMSetting
  L10_1 = L9_1
  L9_1 = L9_1.addItem
  L11_1 = "G1014"
  L12_1 = "\231\170\129\229\143\145\228\186\139\228\187\182\233\133\141\231\189\174\229\153\168"
  L13_1 = "g1014EmergencyEventConfigurator"
  L9_1(L10_1, L11_1, L12_1, L13_1)
end
L9_1 = GMHelper

function L10_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = PlayerManager
  L2_2 = L1_2
  L1_2 = L1_2.getClientPlayer
  L1_2 = L1_2(L2_2)
  L2_2 = L1_2
  L1_2 = L1_2.sendPacket
  L3_2 = {}
  L3_2.pid = "subVipCheck"
  L1_2(L2_2, L3_2)
end

L9_1.subVipCheck = L10_1
L9_1 = GMHelper

function L10_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = PlayerManager
  L2_2 = L1_2
  L1_2 = L1_2.getClientPlayer
  L1_2 = L1_2(L2_2)
  L2_2 = L1_2
  L1_2 = L1_2.sendPacket
  L3_2 = {}
  L3_2.pid = "g1014ResetUpdateNotice"
  L1_2(L2_2, L3_2)
end

L9_1.resetUpdateNotice = L10_1
L9_1 = GMHelper

function L10_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = PlayerManager
  L2_2 = L1_2
  L1_2 = L1_2.getClientPlayer
  L1_2 = L1_2(L2_2)
  L2_2 = L1_2
  L1_2 = L1_2.sendPacket
  L3_2 = {}
  L3_2.pid = "g1014ResetMysteryAmmoGift"
  L1_2(L2_2, L3_2)
end

L9_1.resetMysteryAmmoGift = L10_1
