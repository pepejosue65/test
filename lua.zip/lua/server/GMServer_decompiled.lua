local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1
L0_1 = require
L1_1 = "feature.PlayerKillBroadcastGMService"
L0_1 = L0_1(L1_1)
L1_1 = require
L2_1 = "feature.NpcPointConfiguratorService"
L1_1 = L1_1(L2_1)
L2_1 = require
L3_1 = "feature.CaptureZoneConfiguratorService"
L2_1 = L2_1(L3_1)
L3_1 = require
L4_1 = "feature.StreetDistrictConfiguratorService"
L3_1 = L3_1(L4_1)
L4_1 = require
L5_1 = "feature.MiniMapZoneIconConfiguratorService"
L4_1 = L4_1(L5_1)
L5_1 = require
L6_1 = "feature.MapFineTuneService"
L5_1 = L5_1(L6_1)
L6_1 = require
L7_1 = "feature.NewsTaskService"
L6_1 = L6_1(L7_1)
L7_1 = require
L8_1 = "feature.EmergencyEventConfiguratorService"
L7_1 = L7_1(L8_1)
L8_1 = require
L9_1 = "feature.ChestConfiguratorService"
L8_1 = L8_1(L9_1)

function L9_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = A0_2 or nil
  if A0_2 then
    L1_2 = A0_2.userId
    L1_2 = GMHelper
    if L1_2 then
      L1_2 = type
      L2_2 = GMHelper
      L2_2 = L2_2.isGMOpen
      L1_2 = L1_2(L2_2)
      L1_2 = GMHelper
      L2_2 = L1_2
      L1_2 = L1_2.isGMOpen
      L3_2 = A0_2.userId
      L1_2 = L1_2 ~= nil and L1_2
    end
  end
  return L1_2
end

L10_1 = GMHelper

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L9_1
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L0_1
  L3_2 = L2_2
  L2_2 = L2_2.broadcastSelfTest
  L4_2 = A1_2
  return L2_2(L3_2, L4_2)
end

L10_1.g1014TestSelfKillBroadcast = L11_1
L10_1 = GMHelper

function L11_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = L9_1
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L0_1
  L3_2 = L2_2
  L2_2 = L2_2.broadcastRandomTest
  return L2_2(L3_2)
end

L10_1.g1014TestRandomKillBroadcast = L11_1
L10_1 = GMHelper

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = L9_1
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L1_1
  L3_2 = L2_2
  L2_2 = L2_2.openSession
  L4_2 = A1_2
  L2_2, L3_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    L5_2 = A1_2
    L4_2 = A1_2.sendPacket
    L6_2 = {}
    L6_2.pid = "onShowToast"
    L6_2.strKey = "\230\151\160\230\179\149\230\137\147\229\188\128 NPC \231\130\185\228\189\141\233\133\141\231\189\174\229\153\168"
    L4_2(L5_2, L6_2)
    L4_2 = false
    L5_2 = L3_2
    return L4_2, L5_2
  end
  L5_2 = A1_2
  L4_2 = A1_2.sendPacket
  L6_2 = {}
  L6_2.pid = "g1014NpcPointConfiguratorOpen"
  L6_2.snapshot = L3_2
  L4_2(L5_2, L6_2)
  L4_2 = true
  return L4_2
end

L10_1.g1014NpcPointConfigurator = L11_1
L10_1 = GMHelper

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L9_1
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L2_1
  L3_2 = L2_2
  L2_2 = L2_2.open
  L4_2 = A1_2
  L2_2, L3_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    L5_2 = A1_2
    L4_2 = A1_2.sendPacket
    L6_2 = {}
    L6_2.pid = "onShowToast"
    L7_2 = "\230\151\160\230\179\149\230\137\147\229\188\128\229\141\160\233\162\134\229\140\186\233\133\141\231\189\174\229\153\168\239\188\154"
    L8_2 = tostring
    L9_2 = L3_2
    L8_2 = L8_2(L9_2)
    L7_2 = L7_2 .. L8_2
    L6_2.strKey = L7_2
    L4_2(L5_2, L6_2)
    L4_2 = false
    return L4_2
  end
  L5_2 = A1_2
  L4_2 = A1_2.sendPacket
  L6_2 = {}
  L6_2.pid = "g1014CaptureZoneConfiguratorOpen"
  L6_2.snapshot = L3_2
  L4_2(L5_2, L6_2)
  L4_2 = true
  return L4_2
end

L10_1.g1014CaptureZoneConfigurator = L11_1
L10_1 = GMHelper

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L9_1
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L8_1
  L3_2 = L2_2
  L2_2 = L2_2.open
  L4_2 = A1_2
  L2_2, L3_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    L5_2 = A1_2
    L4_2 = A1_2.sendPacket
    L6_2 = {}
    L6_2.pid = "onShowToast"
    L7_2 = "\230\151\160\230\179\149\230\137\147\229\188\128\229\174\157\231\174\177\233\133\141\231\189\174\229\153\168\239\188\154"
    L8_2 = tostring
    L9_2 = L3_2
    L8_2 = L8_2(L9_2)
    L7_2 = L7_2 .. L8_2
    L6_2.strKey = L7_2
    L4_2(L5_2, L6_2)
    L4_2 = false
    return L4_2
  end
  L5_2 = A1_2
  L4_2 = A1_2.sendPacket
  L6_2 = {}
  L6_2.pid = "g1014ChestConfiguratorOpen"
  L6_2.snapshot = L3_2
  L4_2(L5_2, L6_2)
  L4_2 = true
  return L4_2
end

L10_1.g1014ChestConfigurator = L11_1
L10_1 = GMHelper

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L9_1
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L3_1
  L3_2 = L2_2
  L2_2 = L2_2.open
  L4_2 = A1_2
  L2_2, L3_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    L5_2 = A1_2
    L4_2 = A1_2.sendPacket
    L6_2 = {}
    L6_2.pid = "onShowToast"
    L7_2 = "\230\151\160\230\179\149\230\137\147\229\188\128\232\161\151\229\140\186\233\133\141\231\189\174\229\153\168\239\188\154"
    L8_2 = tostring
    L9_2 = L3_2
    L8_2 = L8_2(L9_2)
    L7_2 = L7_2 .. L8_2
    L6_2.strKey = L7_2
    L4_2(L5_2, L6_2)
    L4_2 = false
    return L4_2
  end
  L5_2 = A1_2
  L4_2 = A1_2.sendPacket
  L6_2 = {}
  L6_2.pid = "g1014StreetDistrictConfiguratorOpen"
  L6_2.snapshot = L3_2
  L4_2(L5_2, L6_2)
  L4_2 = true
  return L4_2
end

L10_1.g1014StreetDistrictConfigurator = L11_1

function L10_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  if A0_2 then
    L3_2 = type
    L4_2 = A0_2.sendPacket
    L3_2 = L3_2(L4_2)
    if L3_2 == "function" then
      goto lbl_9
    end
  end
  do return end
  ::lbl_9::
  L3_2 = tostring
  L4_2 = A2_2 or L4_2
  if not A2_2 then
    L4_2 = "\230\147\141\228\189\156\229\164\177\232\180\165"
  end
  L3_2 = L3_2(L4_2)
  if A1_2 and A2_2 == "enabled" then
    L3_2 = "\229\156\176\229\155\190\229\190\174\232\176\131\230\168\161\229\188\143\229\183\178\229\188\128\229\144\175\239\188\155\229\134\141\230\172\161\231\130\185\229\135\187\229\143\175\233\128\128\229\135\186\229\185\182\230\129\162\229\164\141\229\142\159\232\131\140\229\140\133"
  elseif A1_2 and A2_2 == "disabled" then
    L3_2 = "\229\156\176\229\155\190\229\190\174\232\176\131\230\168\161\229\188\143\229\183\178\229\133\179\233\151\173\239\188\140\229\142\159\232\131\140\229\140\133\229\183\178\230\129\162\229\164\141"
  elseif A1_2 and A2_2 == "already_active" then
    L3_2 = "\229\156\176\229\155\190\229\190\174\232\176\131\230\168\161\229\188\143\229\183\178\231\187\143\229\188\128\229\144\175"
  elseif A1_2 and A2_2 == "saving" then
    L3_2 = "\230\173\163\229\156\168\228\191\157\229\173\152\229\156\176\229\155\190\239\188\140\232\175\183\229\139\191\232\191\155\232\161\140\230\150\185\229\157\151\230\147\141\228\189\156"
  end
  L5_2 = A0_2
  L4_2 = A0_2.sendPacket
  L6_2 = {}
  L6_2.pid = "onShowToast"
  L6_2.strKey = L3_2
  L4_2(L5_2, L6_2)
end

L11_1 = GMHelper

function L12_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = L9_1
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L5_1
  L3_2 = L2_2
  L2_2 = L2_2.toggle
  L4_2 = A1_2
  L2_2, L3_2 = L2_2(L3_2, L4_2)
  L4_2 = L10_1
  L5_2 = A1_2
  L6_2 = L2_2
  L7_2 = L3_2
  L4_2(L5_2, L6_2, L7_2)
  return L2_2
end

L11_1.g1014ToggleMapFineTune = L12_1
L11_1 = GMHelper

function L12_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = L9_1
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L5_1
  L3_2 = L2_2
  L2_2 = L2_2.save
  L4_2 = A1_2
  L2_2, L3_2 = L2_2(L3_2, L4_2)
  L4_2 = L10_1
  L5_2 = A1_2
  L6_2 = L2_2
  L7_2 = L3_2
  L4_2(L5_2, L6_2, L7_2)
  return L2_2
end

L11_1.g1014SaveMapFineTune = L12_1
L11_1 = GMHelper

function L12_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L9_1
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L4_1
  L3_2 = L2_2
  L2_2 = L2_2.open
  L4_2 = A1_2
  L2_2, L3_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    L5_2 = A1_2
    L4_2 = A1_2.sendPacket
    L6_2 = {}
    L6_2.pid = "onShowToast"
    L7_2 = "\230\151\160\230\179\149\230\137\147\229\188\128\229\176\143\229\156\176\229\155\190\229\155\190\230\160\135\230\145\134\230\148\190\229\153\168\239\188\154"
    L8_2 = tostring
    L9_2 = L3_2
    L8_2 = L8_2(L9_2)
    L7_2 = L7_2 .. L8_2
    L6_2.strKey = L7_2
    L4_2(L5_2, L6_2)
    L4_2 = false
    return L4_2
  end
  L5_2 = A1_2
  L4_2 = A1_2.sendPacket
  L6_2 = {}
  L6_2.pid = "g1014MiniMapZoneIconConfiguratorOpen"
  L6_2.snapshot = L3_2
  L4_2(L5_2, L6_2)
  L4_2 = true
  return L4_2
end

L11_1.g1014MiniMapZoneIconConfigurator = L12_1

function L11_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = L9_1
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    L3_2 = false
    return L3_2
  end
  L3_2 = A1_2
  L3_2 = L3_2()
  L5_2 = A0_2
  L4_2 = A0_2.sendPacket
  L6_2 = {}
  L6_2.pid = "onShowToast"
  L7_2 = A2_2 or L7_2
  if not L3_2 or not A2_2 then
    L7_2 = "\230\150\176\233\151\187\230\181\139\232\175\149\230\147\141\228\189\156\229\164\177\232\180\165"
  end
  L6_2.strKey = L7_2
  L4_2(L5_2, L6_2)
  return L3_2
end

L12_1 = GMHelper

function L13_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L11_1
  L3_2 = A1_2
  
  function L4_2()
    local L0_3, L1_3, L2_3
    L0_3 = L6_1
    L1_3 = L0_3
    L0_3 = L0_3.gmResetDaily
    L2_3 = A1_2
    return L0_3(L1_3, L2_3)
  end
  
  L5_2 = "\230\150\176\233\151\187\230\175\143\230\151\165\228\187\187\229\138\161\233\135\141\231\189\174\232\175\183\230\177\130\229\183\178\230\143\144\228\186\164"
  return L2_2(L3_2, L4_2, L5_2)
end

L12_1.g1014NewsResetDaily = L13_1
L12_1 = GMHelper

function L13_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L11_1
  L3_2 = A1_2
  
  function L4_2()
    local L0_3, L1_3, L2_3
    L0_3 = L6_1
    L1_3 = L0_3
    L0_3 = L0_3.gmCompleteAll
    L2_3 = A1_2
    return L0_3(L1_3, L2_3)
  end
  
  L5_2 = "\230\150\176\233\151\187\228\187\187\229\138\161\229\174\140\230\136\144\232\175\183\230\177\130\229\183\178\230\143\144\228\186\164"
  return L2_2(L3_2, L4_2, L5_2)
end

L12_1.g1014NewsCompleteAll = L13_1
L12_1 = GMHelper

function L13_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L11_1
  L3_2 = A1_2
  
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L6_1
    L1_3 = L0_3
    L0_3 = L0_3.gmAddCitizenPoints
    L2_3 = A1_2
    L3_3 = 10
    return L0_3(L1_3, L2_3, L3_3)
  end
  
  L5_2 = "\229\162\158\229\138\16010\229\184\130\230\176\145\231\130\185\230\149\176\232\175\183\230\177\130\229\183\178\230\143\144\228\186\164"
  return L2_2(L3_2, L4_2, L5_2)
end

L12_1.g1014NewsAddPoints = L13_1
L12_1 = GMHelper

function L13_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L11_1
  L3_2 = A1_2
  
  function L4_2()
    local L0_3, L1_3, L2_3
    L0_3 = L6_1
    L1_3 = L0_3
    L0_3 = L0_3.gmSettleCurrentMonth
    L2_3 = A1_2
    return L0_3(L1_3, L2_3)
  end
  
  L5_2 = "UTC\230\156\136\231\187\147\230\168\161\230\139\159\232\175\183\230\177\130\229\183\178\230\143\144\228\186\164"
  return L2_2(L3_2, L4_2, L5_2)
end

L12_1.g1014NewsSettleMonth = L13_1
L12_1 = GMHelper

function L13_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L9_1
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = L7_1
  L3_2 = L2_2
  L2_2 = L2_2.open
  L4_2 = A1_2
  L2_2, L3_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    L5_2 = A1_2
    L4_2 = A1_2.sendPacket
    L6_2 = {}
    L6_2.pid = "onShowToast"
    L7_2 = "\230\151\160\230\179\149\230\137\147\229\188\128\231\170\129\229\143\145\228\186\139\228\187\182\233\133\141\231\189\174\229\153\168\239\188\154"
    L8_2 = tostring
    L9_2 = L3_2
    L8_2 = L8_2(L9_2)
    L7_2 = L7_2 .. L8_2
    L6_2.strKey = L7_2
    L4_2(L5_2, L6_2)
    L4_2 = false
    return L4_2
  end
  L5_2 = A1_2
  L4_2 = A1_2.sendPacket
  L6_2 = {}
  L6_2.pid = "g1014EmergencyEventConfiguratorOpen"
  L6_2.snapshot = L3_2
  L4_2(L5_2, L6_2)
  L4_2 = true
  return L4_2
end

L12_1.g1014EmergencyEventConfigurator = L13_1
L12_1 = true
return L12_1
